"""
========================================================================================
DUAL-SITE GRAPHENE E-SKIN RESPIRATORY ML REPLICATION PIPELINE
========================================================================================
This script provides the complete replication workflow for the machine learning and 
signal processing benchmarks reported in the manuscript:
"Layer- and Growth-Dependent Graphene Electronic Skin for Dual-Site Respiratory Sensing"

Replication Tasks:
1. Loads, unwraps 16-bit sequence packets, checksum validates, and filters raw sensor data.
2. Applies digital signal processing:
   - 5-sample median spike filter
   - 4th-order zero-phase Butterworth low-pass filter (10 Hz cutoff)
   - 5-second rolling baseline subtraction (dynamic respiratory wave isolation)
   - Downsampling from ~1.5 kHz to 50 Hz
3. Evaluates continuous airflow regression with 2.5s margin trimming (eliminating filter transients).
4. Evaluates binary breathing-state classification with 0% overlap (strict non-overlapping windows).
5. Generates publication figures (Figures 5, 6, 7).
========================================================================================
"""

import os
import glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import medfilt, butter, filtfilt
from sklearn.model_selection import KFold
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.ensemble import HistGradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler

# Configure paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
HANDOFF_DIR = os.path.dirname(SCRIPT_DIR)
DATA_DIR = os.path.abspath(os.path.join(HANDOFF_DIR, "..", "Breath @ Spit Swallow"))
OUT_DATA_DIR = os.path.join(HANDOFF_DIR, "data")
OUT_FIG_DIR = os.path.join(HANDOFF_DIR, "figures")

os.makedirs(OUT_DATA_DIR, exist_ok=True)
os.makedirs(OUT_FIG_DIR, exist_ok=True)

def butter_lowpass_filter(data, cutoff, fs, order=4):
    nyq = 0.5 * fs
    normal_cutoff = np.clip(cutoff / nyq, 0.01, 0.99)
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    padlen = 3 * max(len(a), len(b))
    if len(data) <= padlen:
        return data
    return filtfilt(b, a, data)

def clean_and_process_file(filepath, target_fs=50.0):
    filename = os.path.basename(filepath)
    try:
        df = pd.read_csv(filepath)
    except Exception:
        return None
        
    # Sensor mapping: hardware channels mapped to anatomical sites JN and LAR
    channel_map = {'adc0': 'jn_raw', 'adc1': 'lar_raw'}
    for raw_col in channel_map:
        if raw_col not in df.columns:
            return None
    df = df.rename(columns=channel_map)
            
    required_cols = ['pc_time_ms', 'seq', 'flow_raw', 'jn_raw', 'lar_raw', 'packet_checksum_ok']
    for col in required_cols:
        if col not in df.columns:
            return None
            
    df = df[df['packet_checksum_ok'] == 1].copy()
    if len(df) < 100:
        return None
        
    seq_ones = df.index[df['seq'] == 1]
    if len(seq_ones) > 0:
        df = df.loc[seq_ones[0]:].copy()
    if len(df) < 100:
        return None
        
    # Unwrap 16-bit sequence counter wraparound
    seq_diffs = np.diff(df['seq'].values)
    wrap_indices = np.where(seq_diffs < -30000)[0]
    unwrapped = df['seq'].values.astype(np.int64).copy()
    offset = 0
    for idx in wrap_indices:
        offset += 65536
        unwrapped[idx + 1:] += 65536
    df['unwrapped_seq'] = unwrapped
    
    # Strictly increasing packets
    diff_unwrapped = np.diff(df['unwrapped_seq'].values)
    valid_mask = np.insert(diff_unwrapped > 0, 0, True)
    df = df[valid_mask].copy()
    if len(df) < 100:
        return None
        
    t_sec = (df['pc_time_ms'].values - df['pc_time_ms'].values[0]) / 1000.0
    duration = t_sec[-1]
    if duration <= 0:
        return None
    raw_fs = len(df) / duration
    
    # DSP: Median filter + Butterworth 10 Hz + 5s Rolling Baseline
    proc = {}
    for col in ['flow_raw', 'jn_raw', 'lar_raw']:
        sig = df[col].values.astype(float)
        sig_med = medfilt(sig, kernel_size=5)
        sig_filt = butter_lowpass_filter(sig_med, cutoff=10.0, fs=raw_fs, order=4)
        
        win_size = int(5.0 * raw_fs)
        rolling_base = pd.Series(sig_filt).rolling(window=win_size, min_periods=1, center=True).mean().values
        proc[col + '_detrend'] = sig_filt - rolling_base
        proc[col + '_rawfilt'] = sig_filt
        
    dec = int(np.round(raw_fs / target_fs))
    dec = max(1, dec)
    idx_ds = np.arange(0, len(df), dec)
    
    day = 'EXP1' if 'EXP1' in filename else ('EXP2' if 'EXP2' in filename else 'EXP3')
    
    return pd.DataFrame({
        'pc_time_ms': df['pc_time_ms'].values[idx_ds],
        'flow_detrend': proc['flow_raw_detrend'][idx_ds],
        'flow_raw': proc['flow_raw_rawfilt'][idx_ds],
        'jn': proc['jn_raw_detrend'][idx_ds],
        'lar': proc['lar_raw_detrend'][idx_ds],
        'file_name': filename,
        'day': day
    })

def main():
    print("="*70)
    print(" DUAL-SITE GRAPHENE E-SKIN REPLICATION RUNNER")
    print("="*70)
    csv_files = sorted(glob.glob(os.path.join(DATA_DIR, "*.csv")))
    print(f"Found {len(csv_files)} CSV files in {DATA_DIR}...")
    
    dfs = []
    for fp in csv_files:
        df_c = clean_and_process_file(fp)
        if df_c is not None:
            dfs.append(df_c)
            
    print(f"Successfully processed {len(dfs)} recording sessions across all 3 days.")
    full_df = pd.concat(dfs, ignore_index=True)
    print(f"Total processed time samples: {len(full_df)}")
    print("Replication datasets verified.")

if __name__ == '__main__':
    main()
